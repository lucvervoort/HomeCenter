using System;
using System.Collections.Generic;
using System.Text;
using Canna.Prolog.Runtime.Objects;

namespace Canna.Prolog.Runtime
{
    //class PredicateHelper
    //{
    //    public static string GetPredicateName(PredicateIndicator pi)
    //    {
    //        StringBuilder sb = new StringBuilder(pi.Name);
    //        sb.Append("_");
    //        sb.Append(pi.Arity);
    //        return sb.ToString();
    //    }

    //    public static Structure GetPI(string name, int arity)
    //    {
    //        return new Structure("/", new Structure(name), new Integer(arity));
    //    }

    //}
}
