# ECharts add-on for PivotData
How to use:

* remove dependencies on chartist.js and default jquery.nrecoPivotChart.js
* include ECharts and jquery.nrecoPivotChart-echarts.js:
```
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/echarts/4.1.0/echarts.common.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/nreco/pivotdata/master/webpivot/ECharts/jquery.nrecopivotchart-echarts.js"></script>
```
Online demo: [PivotData microservice with ECharts](http://pivotdataservice.nrecosite.com/pivotdataservice/?chartlib=ECharts)
