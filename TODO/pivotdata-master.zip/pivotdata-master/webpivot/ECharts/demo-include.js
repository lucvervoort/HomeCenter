/* loads dependencies for online demo */
documentWriteScript("//cdnjs.cloudflare.com/ajax/libs/echarts/4.1.0/echarts.common.min.js");
documentWriteScript("https://cdn.rawgit.com/nreco/pivotdata/master/webpivot/ECharts/jquery.nrecopivotchart-echarts.js");