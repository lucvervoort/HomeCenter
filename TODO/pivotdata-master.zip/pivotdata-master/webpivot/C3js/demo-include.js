/* loads dependencies for online demo */
documentWriteScript("//cdnjs.cloudflare.com/ajax/libs/d3/4.13.0/d3.min.js");
documentWriteScript("//cdnjs.cloudflare.com/ajax/libs/c3/0.6.0/c3.min.js");
documentWriteStylesheet("//cdnjs.cloudflare.com/ajax/libs/c3/0.6.0/c3.min.css");
documentWriteScript("https://cdn.rawgit.com/nreco/pivotdata/master/webpivot/C3js/jquery.nrecopivotchart-c3.js");