﻿namespace Obvs.ActiveMQ
{
    public enum AcknowledgementMode
    {
        AutoAcknowledge,
        ClientAcknowledge
    }
}