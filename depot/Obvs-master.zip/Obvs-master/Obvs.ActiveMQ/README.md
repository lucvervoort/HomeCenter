[ActiveMQ](https://github.com/apache/activemq) transport for [Obvs](https://github.com/christopherread/Obvs); 
please see the main Obvs repository for documentation and examples.
