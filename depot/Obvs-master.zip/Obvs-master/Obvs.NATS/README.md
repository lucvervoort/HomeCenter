# Obvs.NATS

[NATS](https://github.com/nats-io) transport support for [Obvs](https://github.com/christopherread/Obvs).

## NuGet Package

[![NuGet](https://img.shields.io/nuget/v/Obvs.NATS.svg)](https://www.nuget.org/packages/Obvs.NATS/)

See the [NuGet Package Obvs.NATS](https://www.nuget.org/packages/Obvs.NATS/).
