using System.Text;

namespace Obvs.Serialization.Json
{
    public static class JsonMessageDefaults
    {
        public static readonly Encoding Encoding = new UTF8Encoding();
    }
}