namespace Obvs.Monitoring.Tests
{
    public class TestMessage
    {
    }
}