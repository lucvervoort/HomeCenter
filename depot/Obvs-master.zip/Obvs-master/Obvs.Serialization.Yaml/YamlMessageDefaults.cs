using System.Text;

namespace Obvs.Serialization.Yaml
{
    public static class YamlMessageDefaults
    {
        public static readonly Encoding Encoding = new UTF8Encoding();
    }
}