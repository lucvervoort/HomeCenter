[RabbitMQ](https://github.com/rabbitmq) transport support for [Obvs](https://github.com/christopherread/Obvs).
Please see the main [Obvs](https://github.com/christopherread/Obvs) repository for examples.
