using System.Text;

namespace Obvs.Serialization.Xml
{
    public static class XmlSerializerDefaults
    {
        public static readonly Encoding Encoding = new UTF8Encoding();
    }
}