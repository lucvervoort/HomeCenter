﻿using NetMQ.Sockets;

namespace Obvs.NetMQ.Configuration
{
    public enum SocketType
    {
         Server,
         Client
    }
}