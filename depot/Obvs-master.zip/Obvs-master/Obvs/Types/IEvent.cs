namespace Obvs.Types
{
    public interface IEvent : IMessage
    {
    }
}