namespace Obvs.Types
{
    public interface IMessage
    {
    }
}