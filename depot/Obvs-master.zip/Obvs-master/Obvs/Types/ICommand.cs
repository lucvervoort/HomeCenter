namespace Obvs.Types
{
    public interface ICommand : IMessage
    {
    }
}