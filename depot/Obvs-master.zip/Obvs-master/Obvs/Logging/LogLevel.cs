﻿namespace Obvs.Logging
{
    public enum LogLevel
    {
        Debug,
        Info,
        Warn,
        Error
    }
}