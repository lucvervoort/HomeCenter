﻿The zproto folder is added by NuGet for NetMQ.zproto
Additional files added to the zproto folder:
	License.xml copied from code elsewhere in NetMQ
	Generate.bat
	zre_msg.xml based on the file at zeromq\zyre\src (https://github.com/zeromq/zyre/tree/master/src)


