﻿namespace SamplePeer
{
    public class Group
    {
        public string GroupName { get; }

        public Group(string groupName)
        {
            GroupName = groupName;
        }
    }
}
