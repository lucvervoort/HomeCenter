﻿A Zyre Peer can be a server, a  client or both.
Run the Run3SamplePeers.bat file in the build directory to launch 3 of these SamplePeer instances.





