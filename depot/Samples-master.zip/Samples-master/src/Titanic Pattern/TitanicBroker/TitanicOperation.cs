﻿namespace TitanicProtocol;

/// <summary>
///     defines the possible operations carried out by Titanic
/// </summary>
public enum TitanicOperation { Request, Reply, Close }