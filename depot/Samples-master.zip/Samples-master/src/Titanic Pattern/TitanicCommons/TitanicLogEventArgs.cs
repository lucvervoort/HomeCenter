﻿namespace TitanicCommons;

public class TitanicLogEventArgs : EventArgs
{
    public string Info { get; set; }
}