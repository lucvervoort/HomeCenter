﻿namespace MDPCommons;

public class MDPLogEventArgs : EventArgs
{
    public string Info { get; set; }
}