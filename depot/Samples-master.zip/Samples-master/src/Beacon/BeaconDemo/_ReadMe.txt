﻿This project demonstrates the use of NetMQBeacon as set for the Docs\beacon.md.
The same file is also at http://netmq.readthedocs.org/en/latest/beacon/
To see how this works, start multiple instances and see how they interact with each other.

