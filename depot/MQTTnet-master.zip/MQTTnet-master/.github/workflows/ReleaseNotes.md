* [Client] Restored _Server_ and _Port_ behavior of client options (#2005).
