namespace NetMQ.Core.Transports
{
    internal static class V3Protocol
    {
        public const string PingCommand = "PING";
        public const string PongCommand = "PONG";
    }
}